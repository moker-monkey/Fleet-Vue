import * as api from './api'
import './mock'

export default api
